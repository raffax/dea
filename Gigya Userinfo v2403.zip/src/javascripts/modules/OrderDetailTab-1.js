import React, { useState } from 'react';
import { render } from 'react-dom';
import { Tabs, TabList, Tab, TabPanel } from '@zendeskgarden/react-tabs';
import { ThemeProvider, DEFAULT_THEME } from '@zendeskgarden/react-theming';
import { Modal, Header, Body as ModalBody, Footer, FooterItem, Close } from '@zendeskgarden/react-modals';
import { Grid, Row, Col } from '@zendeskgarden/react-grid';
import { Field, Label, Input, Message, Radio, Select } from '@zendeskgarden/react-forms';
import { Body, Cell, Head, HeaderCell, HeaderRow, Row as TableRow, Table } from '@zendeskgarden/react-tables';
import { SM, MD, LG, XL, XXL, XXXL, Code } from '@zendeskgarden/react-typography';
import { Spinner } from '@zendeskgarden/react-loaders';
import { Button } from '@zendeskgarden/react-buttons';

export function OrderDetailTab(orderDataObject) {
  const gaddress_api_url = localStorage.getItem('gaddress_api_url');
  const orderData = orderDataObject.orderData;
  const customerId = localStorage.getItem('customerId');
  const countryCode = orderData.country; 
  console.log('[orderDetailTab] Country code: '+countryCode);
  const shippingData = orderDataObject.shippingData;
  //console.log("[orderDetailTab]  orderData= "+JSON.stringify(orderData,null,2));
  console.log("[orderDetailTab]  shippingData= "+JSON.stringify(shippingData,null,2));
  const closedShipments = shippingData.closed;
  const openShipments = shippingData.open;
  // il cliente ha detto che non è rilevante che siano spedizioni chiuse o aperte, quindi le concateno
  const allShipments = openShipments.concat(closedShipments);

  const addressesList = shippingData.addresses;

  const [selectedTab, setSelectedTab] = useState('order-tab');
  const [visible, setVisible] = useState(false);
  const [promoList, setPromoList] = useState([]);
  const [promo, setPromo] = useState('');
  const [radioValue, setRadioValue] = useState(null);
  const [saveButton, setSaveButton] = useState(true);
  const [disabledBtn, setDisabledBtn] = useState(false);

  const [confirmVisible, setConfirmVisible] = useState(false);
  const [invalidAddress, setInvalidAddress] = useState('');

  

  gproxy.customer.order.promoList(orderData).then(result => {

    console.log("Promo list", result);
    setPromoList(result);

  });

  const handleShow = () => {
    console.log('RADIO VALUE', radioValue);
    var checkedValue = document.querySelector('.isSelected:checked').value;
    setPromo(checkedValue);
    setVisible(true);
  }

  const handleClose = () => {
    setPromo(null);
    setVisible(false);
  }
  
  var onLibraryAdded = () => {
    var lang = 'en'; // VALORE DEFAULT accordato con Manfredi in data 18/04/2023 - la ricerca funziona ugualmente
    var countryISO = countryCode.toUpperCase();
    if(countryISO === 'UK') {
      countryISO = 'GB';
    }
    gaddress(lang, countryISO, function() {
      gaddress.bind(document.getElementById('addressLine1'), gaddress.types.ADDRESS, fillInAddress);
  
    });
    const fillInAddress = (field, data) => {
      document.getElementById('addressLine1').value = '';
	    document.getElementById('postalCode').value = '';
	    document.getElementById('city').value = '';
      if(document.getElementById('state')){
        document.getElementById('state').value = '';
      }
	    if (data.postal_code) {
        document.getElementById('postalCode').value = data.postal_code;
      }
      if (data.city) {
        document.getElementById('city').value = data.city;
      }
      if (data.street) {
        document.getElementById('addressLine1').value = gaddress.format(data, gaddress.formats.ADDRESS);        
      }
      if (data.state && countryISO === 'US') {
        document.getElementById('state').value = data.state;
      }
    }
  }

  const handleOrderChange = (orderData) => {
    var addressLine1 = document.getElementById('addressLine1').value;
    var zipCode = document.getElementById('postalCode').value;
    var city = document.getElementById('city').value;
    var district = document.getElementById('district').value;
    var country = document.getElementById('country').value;
    var county = document.getElementById('county').value;


    var query = {
      'address': addressLine1,
      'postal_code': zipCode,
      'city': city
    }

    console.log('[handleOrderChange] - looking up gaddress ')
    gaddress.lookup(query, function(address) {

      console.log("Address status", address.status);

      if(address.status) {
        onSaveClicked(orderData);
      } else {
        setInvalidAddress(addressLine1 + ', ' + city + ', ' + zipCode);
        setConfirmVisible(true);
      }
      
    });
  }

  var countryIsUs = (countryCode === 'us') ? true : false;

  
  AddLibrary(gaddress_api_url, onLibraryAdded);

  return (
    <ThemeProvider theme={{ ...DEFAULT_THEME }}>
      <Tabs selectedItem={selectedTab} onChange={setSelectedTab}>
        <TabList>
          <Tab item="order-tab">Order Details</Tab>
          <Tab item="shipping-tab">Shipping List</Tab>
          <Tab item="promocode-tab">Promocodes</Tab>
          <Tab item="addresses-tab">Address List</Tab>
        </TabList>
        <TabPanel item="order-tab">
          <Grid>
            <Row justifyContent="start">
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Order Number</Label>
                  <Input defaultValue={orderData.ref} readOnly/>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Customer ID</Label>
                  <Input defaultValue={customerId} readOnly/>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Order Status</Label>
                  <Input defaultValue={orderData.status + " (" + orderData.statusCode + ")"} readOnly />
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Offert Type</Label>
                  <Input defaultValue={orderData.offerType} readOnly />
                </Field>
              </Col>
            </Row>
            <Row justifyContent='start'>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Channel</Label>
                  <Input defaultValue={orderData.channel} readOnly />
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Order Date</Label>
                  <Input defaultValue={orderData.creationDate ? new Date(orderData.creationDate).toLocaleDateString("it-IT") : "N/A"} readOnly />
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Product Name</Label>
                  <Input defaultValue={orderData.name} readOnly />
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Title Code</Label>
                  <Input defaultValue={orderData.productIdNative} readOnly />
                </Field>
              </Col>
            </Row>
            <Row justifyContent='start'>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Variant ID</Label>
                  <Input defaultValue={orderData.variantId} readOnly />
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Discard Cause</Label>
                  <Input defaultValue={orderData.discardCause} readOnly />
                </Field>
              </Col>
            </Row>
            <Row justifyContent='start'>
              <div style={{padding: '15px'}}>
              <XL></XL>
              <XL>Shipping Address</XL>
              <XL></XL>
              </div>
            </Row>
            <Row justifyContent='start'>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>First name</Label>
                  <Input defaultValue={shippingData.address.firstName} id="firstName" onChange={() => setDisabledBtn(false)}/>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Last name</Label>
                  <Input defaultValue={shippingData.address.lastName} id="lastName" onChange={() => setDisabledBtn(false)}/>
                </Field>
              </Col>
              <Col sm={6} alignSelf="center">
                <Field>
                  <Label>Address</Label>
                  <Input defaultValue={shippingData.address.address} id="addressLine1" onChange={() => setDisabledBtn(false)}/>
                </Field>
              </Col>
            </Row>
            <Row justifyContent='start'>
              <Col sm={2} alignSelf="center">
                <Field>
                  <Label>C/O</Label>
                  <Input defaultValue={shippingData.address.addressee} id="c/o" onChange={() => setDisabledBtn(false)}/>
                </Field>
              </Col>
              <Col sm={1} alignSelf="center">
                <Field>
                  <Label>Flat/Floor</Label>
                  <Input defaultValue={shippingData.address.info} id="info" onChange={() => setDisabledBtn(false)}/>
                </Field>
              </Col>
              <Col sm={1} alignSelf="center">
                <Field>
                  <Label>ZIP Code</Label>
                  <Input defaultValue={shippingData.address.zip} id="postalCode" onChange={() => setDisabledBtn(false)}/>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>City</Label>
                  <Input defaultValue={shippingData.address.city} id="city" onChange={() => setDisabledBtn(false)}/>
                </Field>
              </Col>
              <Col sm={2} alignSelf="center">
                <Field>
                  <Label> Hamlet</Label>
                  <Input defaultValue={shippingData.address.district} id="district" onChange={() => setDisabledBtn(false)} />
                </Field>
              </Col>     
              <Col sm={2} alignSelf="center">
                <Field>
                  <Label> Postal District</Label>
                  <Input defaultValue={shippingData.address.postalDistrict} readOnly />
                </Field>
              </Col>                       
              <Col sm={2} alignSelf="center">
                <Field>
                  <Label> County</Label>
                  <Input defaultValue={shippingData.address.county} id="county" onChange={() => setDisabledBtn(false)}/>
                </Field>
              </Col>
              <Col sm={2} alignSelf="center">
                <Field>
                  <Label>Country</Label>
                  <Input defaultValue={shippingData.address.country} id="country" onChange={() => setDisabledBtn(false)}/>
                </Field>
              </Col>
            </Row>
            <Row alignItems='end'>
              <div style={{padding:'15px'}}>
                {saveButton && <Button id='saveButton' onClick={() => handleOrderChange(orderData)} disabled={disabledBtn}>Save</Button>}
                <MD id='savingMessage'></MD>
              </div>
            </Row>
            <Row justifyContent="start">
              <Col sm={4} alignSelf="end">
                {confirmVisible && (
                  <Modal onClose={() => setConfirmVisible(false)}>
                    <Header tag="h2">Confirm Address Edit</Header>
                    <ModalBody>
                      This address might not be valid: {invalidAddress}. Are you sure you want to save it?
                    </ModalBody>
                    <Footer>
                      <FooterItem>
                        <Button id='cancelAddressButton' onClick={() => setConfirmVisible(false)} isBasic>
                          Cancel
                        </Button>
                      </FooterItem>
                      <FooterItem>
                        <Button isPrimary id='confirmAddressButton' onClick={() => onSaveClicked(orderData)}>
                          Confirm
                        </Button>
                      </FooterItem>
                    </Footer>
                    <Close aria-label="Close modal" />
                  </Modal>
                )}
              </Col>
            </Row>
          </Grid>
        </TabPanel>
        <TabPanel item="shipping-tab">
          <XL>Shipments</XL>
          <div style={{ overflowX: 'auto' }}>
            <div style={{ maxHeight: 500, overflowY: 'auto' }}>
              <Table style={{ minWidth: 500 }}>
                <Head>
                  <HeaderRow>
                    <HeaderCell>Shipping Order ID</HeaderCell>
                    <HeaderCell>Creation Date</HeaderCell>
                    <HeaderCell>Shipment Status</HeaderCell>                    
                    <HeaderCell>Shipment Date</HeaderCell>
                    <HeaderCell>Payment Status</HeaderCell>
                    <HeaderCell>Payment Type</HeaderCell>
                    <HeaderCell>Payment Date</HeaderCell>
                    <HeaderCell>Price</HeaderCell>
                  </HeaderRow>
                </Head>
                <Body>
                  {allShipments != [] ? allShipments.map(shipment => (
                    <TableRow key={shipment.id}>
                      <Cell isMinimum>
                        <Button isBasic id={'copyRef' + shipment.id} onClick={() => copyText(shipment.id)}>{shipment.ref}</Button>
                        <SM id='copied'></SM>
                      </Cell>
                      <Cell>{shipment.shipment.creationDate ? new Date(shipment.shipment.creationDate).toLocaleDateString("it-IT") : "N/A"}</Cell>
                      <Cell>{shipment.shipment.status} ({shipment.shipment.statusCode})</Cell>
                      <Cell>{shipment.shipment.shippingDate ? new Date(shipment.shipment.shippingDate).toLocaleDateString("it-IT") : "N/A"}</Cell>
                      <Cell>{shipment.payment.status}</Cell>
                      <Cell>{shipment.payment.method}</Cell>
                      <Cell>{shipment.shipment.paymentDate ? new Date(shipment.shipment.paymentDate).toLocaleDateString("it-IT") : "N/A"}</Cell>
                      <Cell>{shipment.currency}{shipment.amount}</Cell>
                    </TableRow>
                  )) : <MD>This order contains no shipments.</MD>}
                </Body>
              </Table>
            </div>
          </div>
        </TabPanel>
        <TabPanel item="promocode-tab">
          <div style={{ overflowX: 'auto' }}>
            <Table style={{ minWidth: 500 }}>
              <Head>
                <HeaderRow>
                  <HeaderCell isMinimum />
                  <HeaderCell>Promocode Name</HeaderCell>
                </HeaderRow>
              </Head>
            </Table>
            <div style={{ maxHeight: 500, overflowY: 'auto', paddingBottom: '15px' }}>
              <Table>
                <Body>
                  {promoList != [] ? promoList.map(promoCode => (
                    <TableRow key={promoCode}>
                      <Cell isMinimum>
                        <Field>
                          <Radio 
                            className="isSelected"
                            value={promoCode}
                            checked={ radioValue === promoCode }
                            onChange={ event => setRadioValue(event.target.value)}
                          >
                            <Label hidden>Select all tickets</Label>
                          </Radio>
                        </Field>
                      </Cell>
                      <Cell name="promoName">{promoCode}</Cell>
                    </TableRow>
                  )) : <MD>No promocodes were used for this order.</MD>}
                </Body>
              </Table>
            </div>
          </div>
          <Grid>
            <Row justifyContent="start">
              <Col sm={4} alignSelf="center">
                <Input placeholder='New Promocode' name="newPromoCode"/>
              </Col>
              <Col sm={4} alignSelf="center">
                <Button onClick={() => addPromoCode(orderData)}>Add Promocode</Button>
              </Col>
              <Col sm={4} alignSelf="end">
              <Button onClick={() => handleShow()}>Delete</Button>
                {visible && (
                  <Modal onClose={() => handleClose()}>
                    <Header tag="h2">Promocode Deletion</Header>
                    <ModalBody>
                      You're trying to delete '{promo}' promocode. Confirm by typing it below:
                      <Input placeholder='Promocode' id='promoCodeToRemove'/>
                      <MD id='errorMessage'></MD>
                    </ModalBody>
                    <Footer>
                      <FooterItem>
                        <Button onClick={() => handleClose()} isBasic>
                          Cancel
                        </Button>
                      </FooterItem>
                      <FooterItem>
                        <Button isPrimary onClick={() => removePromoCode(orderData)}>
                          Delete
                        </Button>
                      </FooterItem>
                    </Footer>
                    <Close aria-label="Close modal" />
                  </Modal>
                )}
              </Col>
            </Row>
            <Row justifyContent='start'>
              <MD id='promoEdit'></MD>
            </Row>
          </Grid>
        </TabPanel>
        <TabPanel item="addresses-tab">
          <div style={{ overflowY: 'hidden' }}>
            <Table style={{ minWidth: 500 }}>
              <Head>
                <HeaderRow>
                  <HeaderCell>Valid From</HeaderCell>
                  <HeaderCell>To</HeaderCell>
                  <HeaderCell>First Name</HeaderCell>
                  <HeaderCell>Last Name</HeaderCell>
                  <HeaderCell>Address</HeaderCell>
                  <HeaderCell>C/O</HeaderCell>
                  <HeaderCell>Flat/Floor</HeaderCell>
                  <HeaderCell>City</HeaderCell>
                  <HeaderCell>County</HeaderCell>
                  <HeaderCell>ZIP Code</HeaderCell>
                  <HeaderCell>Country</HeaderCell>
                </HeaderRow>
              </Head>
            </Table>
            <div style={{ maxHeight: 500, overflowY: 'auto', paddingBottom: '15px' }}>
              <Table>
                <Body>
                  {addressesList != [] ? addressesList.map(address => (
                    <TableRow key={address.to}>
                      <Cell name="validityFrom">{formatDate(address.from)}</Cell>
                      <Cell name="validityTo">{formatDate(address.to)}</Cell>
                      <Cell name="firstName">{address.address.firstName}</Cell>
                      <Cell name="lastName">{address.address.lastName}</Cell>
                      <Cell name="address">{address.address.address}</Cell>
                      <Cell name="co">{address.address.addressee}</Cell>
                      <Cell name="flatFloor">{address.address.info}</Cell>
                      <Cell name="city">{address.address.city}</Cell>
                      <Cell name="county">{address.address.county}</Cell>
                      <Cell name="zipCode">{address.address.zip}</Cell>
                      <Cell name="country">{address.address?.country}</Cell>
                    </TableRow>
                  )) : <MD>No addresses were found for this order.</MD>}
                </Body>
              </Table>
            </div>
          </div>
        </TabPanel>
      </Tabs>
    </ThemeProvider>
  );

  function addPromoCode(orderData) {
    const newPromoCode = document.getElementsByName('newPromoCode')[0].value;
  
    gproxy.customer.order.promoAdd(orderData, newPromoCode).then((result) => {
      
      console.log("Promo add result", result);
      document.getElementById('promoEdit').innerText = "New promo code added successfully!";

      gproxy.customer.order.promoList(orderData).then(result => {
        console.log("Promo add result", result);
        setPromoList(result);
        window.location.reload();
      });
  
    }).catch(error=>{
  
      console.error("Cannot load promo detail...", error);
      document.getElementById('promoEdit').innerText = "Promo code not added: " + error.errorDetails;
  
    })
  }

  function removePromoCode(orderData) {
    var checkedValue = document.querySelector('.isSelected:checked').value;
    var inputPromoCode = document.getElementById('promoCodeToRemove').value;
    var errorMessage = document.getElementById('errorMessage');

    if (inputPromoCode === checkedValue) {
      gproxy.customer.order.promoRemove(orderData, inputPromoCode).then((result) => {

        console.log("Promo list", result);
        errorMessage.innerText = '';
        setVisible(false);
        document.getElementById('promoEdit').innerText = "Promo code " + inputPromoCode + " removed successfully!";

        gproxy.customer.order.promoList(orderData).then(result => {
          console.log("Promo remove result", result);
          setPromoList(result);
          window.location.reload();
        })
    
      }).catch(error=>{
    
        console.error("Cannot load promo detail...", error);
        document.getElementById('promoEdit').innerText = "Promo code not removed: " + error.errorDetails;
    
      })
    } else {
      errorMessage.style.color = "red";
      errorMessage.innerText = "Input promocode (" + inputPromoCode + ") doesn't match the selected one (" + checkedValue + ").";
    }
  }

  function onSaveClicked(orderData) {
    var confirmationButton = document.getElementById('confirmAddressButton');
    var cancelButton = document.getElementById('cancelAddressButton');
    if(confirmationButton) {
      confirmationButton.disabled = true;
      cancelButton.innerHTML = 'Close';
    }
    var firstName = document.getElementById('firstName').value;
    var lastName = document.getElementById('lastName').value;
    var addressLine1 = document.getElementById('addressLine1').value;
    var co = document.getElementById('c/o').value;
    var info = document.getElementById('info').value;
    var states = document.getElementById('state');
    var country = document.getElementById('country').value;
    var district = document.getElementById('district').value;
    if(states) {
      var selectedState = states.options[states.selectedIndex].value;
    }
    var city = document.getElementById('city').value;
    var postalCode = document.getElementById('postalCode').value;
    //var normCountryCode = getISOCountryFromCountry(countryCode);
    var normCountryCode = getISOCountryFromCountry(country) || country;
    var saveButtonElement = document.getElementById('saveButton');
    //var county=selectedState ? selectedState : document.getElementById('county');
    var county=document.getElementById('county').value;
    
    var address = {
    "firstName": firstName,
    "lastName": lastName,
    "addressLine1": addressLine1,
    "addressee": co,
    "info": info,
    "county": county,
    "postalCode": postalCode,
    "district":district,
    "city": city,
    "normCountryCode": normCountryCode
    }
    setDisabledBtn(true);
    saveButtonElement.innerText = 'Saving';
    console.log("Passing address to gproxy for update");
    console.trace(address);
    gproxy.customer.order.updateAddress(orderData, address).then((status) => {
      console.trace(address);
      console.log("Update Order: ADDRESS  status -> ", status);
      setSaveButton(false);
      document.getElementById('savingMessage').innerHTML = "Data updated successfully!";

      setTimeout(function() {
        setSaveButton(true);
        setDisabledBtn(false);
        document.getElementById('savingMessage').innerHTML = "";
        window.location.reload();
      }, 3000);

    }).catch(error=>{

      console.error("Error", error);
      saveButtonElement.style.borderColor = 'red';
      saveButtonElement.style.color = 'red';
      document.getElementById('savingMessage').innerHTML = "An error occurred while trying to update data. Try again.";      

    })

  }
  
};


function getISOCountryFromCountry(country) {
  var ISOCode;

  switch (country) {
    case "gr":
      ISOCode = "GRC";
      break;
    case "nl":
      ISOCode = "NLD";
      break;
    case "uk":
      ISOCode = "GBR";
      break;
    case "gb":
      ISOCode = "GBR";
      break;
    case "us":
      ISOCode = "USA";
      break;
    case "cz":
      ISOCode = "CZE";
      break;
    case "sk":
      ISOCode = "SVK";
      break;
    case "it":
      ISOCode = "ITA";
      break;
    case "fr":
      ISOCode = "FRA";
      break;
    case "es":
      ISOCode = "ESP";
      break;
    case "de":
      ISOCode = "DEU";
      break;
    case "at":
      ISOCode = "AUT";
      break;
    case "pl":
      ISOCode = "POL";
      break;
  }

  return ISOCode;
}

function formatDate(unixDate) {
  var date = new Date(unixDate);
  var maxDate = new Date('2050-12-31T23:59:59');
  if (date > maxDate) {
    return "-";
  } else {
    return date.toLocaleString("it-IT");
  }
}

function copyText(id) {
  var copyText = document.getElementById('copyRef' + id).textContent;

  navigator.clipboard.writeText(copyText);

  document.getElementById('copied').innerHTML = "Shipping Order ID copied!";
  setTimeout(function() {
    document.getElementById('copied').innerHTML = '';
  }, 2000);
  console.log("Copied the text: " + copyText);
}

export function AddLibrary(urlOfTheLibrary, onLoad) {
  if(document.getElementById('gaddressLibrary')) {
    return;
  }
  const script = document.createElement('script');
  if(onLoad){
    script.onload = onLoad;
  }
  script.src = urlOfTheLibrary;
  script.type = "text/javascript";
  script.async = false;
  if(urlOfTheLibrary.includes('gaddress.js')) {
    script.id = 'gaddressLibrary';
  }
  document.body.appendChild(script);
}