import React, { useState } from 'react';
import { render } from 'react-dom';
import { ThemeProvider, DEFAULT_THEME } from '@zendeskgarden/react-theming';
import styled from 'styled-components';
import { SM, MD, LG, XL, XXL, XXXL, Code } from '@zendeskgarden/react-typography';
import { OrderDetailTab } from "./OrderDetailTab";
import { func } from 'prop-types';

const StyledDiv = styled.div`
  margin-top: ${p => p.theme.space.lg};
`;

var client;

var parentClient;

var parentInstanceGuid;

function parseParams(param_string){
  var param_sub = param_string.replace('#','').split('&');
  var param_obj = param_sub.reduce(function(memo, k){
    var kv = k.split('=');
    memo[kv[0]] = kv[1];
    return memo;
  }, {});
  return param_obj;  //Might be overbuilt but I like it because it returns a very pretty object
};

function getParentClient(parent_guid) {  //Definitely redundant but w/e
  return client.instance(parent_guid)
}

function renderAPIRequestError(error) {
  const container = document.querySelector('.main');
  var errorMessage;

  if(error.includes("account not found")) {
    errorMessage = "No account was found for this requester. If needed, create an account for them.";
  } else {
    errorMessage = error;
  }

  render (
    <ThemeProvider theme={{ ...DEFAULT_THEME }}>
      <StyledDiv>
        <LG hue="red">An error occurred while trying to fetch this user's data:</LG>
        <MD hue="red">{errorMessage}</MD>
      </StyledDiv>
    </ThemeProvider>,
    container
  );
}

export function ModalOrderApp(clientArg) {

  AddLibrary('https://static.zdassets.com/zendesk_app_framework_sdk/2.0/zaf_sdk.min.js');
  
  client = clientArg;
    
  var params = parseParams(window.location.hash); //We start the modal client, then parse any parameters in the url
  // uso lo stesso client del ticket
  
  parentInstanceGuid = params.parent_guid;
  
  parentClient = getParentClient(parentInstanceGuid); //Hopefully this includes the parent_guid we want to send when creating modals
  
  
  var api_key = localStorage.getItem('ticket.' + parentInstanceGuid + '.api_key');
  var gigya_id = localStorage.getItem('ticket.' + parentInstanceGuid + '.gigya_id');
  var country = localStorage.getItem('ticket.' + parentInstanceGuid + '.country');
  var orderData = JSON.parse(localStorage.getItem('ticket.' + parentInstanceGuid + '.orderData'));
  var userx = JSON.parse(localStorage.getItem('ticket.' + parentInstanceGuid + '.userx'));
  console.log("[orderDetails] letto localstorage ticket."+parentInstanceGuid + '.userx');
  console.log("[orderDetails] contenuto: "+JSON.stringify(userx,null,2));
  orderData["country"] = country;

		
  var gproxyLibrary = localStorage.getItem('api_url') + api_key;
  

  var onLoad = function(res) {
		
    console.log("[orderDetails] Il risultato della chiamata getAccountInfo: ", JSON.stringify(res,null,2));

    if (res != {}) {

      console.log("Shipping data: ");
      console.trace(res);
      
      const container = document.querySelector('.main');
      render (
        <OrderDetailTab orderData={orderData} shippingData={res} customerData={userx[0]} />,
        container
      );
      
    } else {
      // Qui invece potete gestire il messaggio di errore dell'authenticate
      console.error("ERROR: Function {getAccountInfo} ran into an error while trying to execute", res);
      renderAPIRequestError(res.errorDetails);
    }
  };  

  var addLibraryCallback = () => getShippingInfo(gigya_id, orderData, onLoad);
  AddLibrary(gproxyLibrary, addLibraryCallback);

}

var getShippingInfo = function (gigyaId, orderData, onOrderInfoLoaded) {

  var callback = function(res) {
    console.log("[orderDetails1] Il risultato della chiamata authenticate: ", res);
  
    if (res.errorCode === 0) {
      gproxy.customer.order.shipments(orderData).then((shipments)=> {
        console.log("This is the order shipments", shipments);
        onOrderInfoLoaded(shipments);
    
      }).catch(error=>{
      
        console.error("Cannot load order shipments...", error);
      
      })
      console.log('getShippingInfo');
    
  
    } else {
      console.error("ERROR: function {authenticate} ran into an error while trying to authenticate the user", res);
      renderAPIRequestError(res.errorDetails);
    }
  }

  authenticate(gigyaId, callback);

}

function refreshOrderList() { 
  gproxy.customer.order.list().then((list)=> {
    console.log("This is the order list", list);
  }).catch(error => {
    console.error("Cannot load order list...", error);
  });
}

var authenticate = function (gigyaId, onAuthenticate) {
  var secret = localStorage.getItem('secret_key');
  gproxy(null, function() {
    
    gproxy.extension.install('gcustomer', {rawdata: true}).then(() => {
      gproxy.protected.authenticate({
        "client": "zendesk-client",
        "secret": secret,
        "handle": gigyaId,
        "callback" : onAuthenticate,
        "persistent" : false,
        "shared": true
      });
    }).catch((error) => {
      console.error("Cannot load extension...", error);
    });
  });

} 

export function AddLibrary(urlOfTheLibrary, onLoad) {
  const script = document.createElement('script');
  if(onLoad){
    script.onload = onLoad;
  }
  script.src = urlOfTheLibrary;
  script.type = "text/javascript";
  script.async = false;
  document.body.appendChild(script);
}