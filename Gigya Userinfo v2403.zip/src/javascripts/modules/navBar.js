import React, { useState } from 'react';
import { render } from 'react-dom';
import { Button } from '@zendeskgarden/react-buttons';
import { ThemeProvider, DEFAULT_THEME } from '@zendeskgarden/react-theming';
import { Field, Label, Checkbox, Input, Message, Radio, Select } from '@zendeskgarden/react-forms';
import { Grid, Row, Col } from '@zendeskgarden/react-grid';
import styled from 'styled-components';
import { SM, MD, LG, XL, XXL, XXXL, Code } from '@zendeskgarden/react-typography';

const StyledDiv = styled.div`
  margin-top: ${p => p.theme.space.lg};
`;

var client;
var instanceGuid;

var pwAPIkey;
var fhAPIkey;
var msAPIkey;

var partwork_gigya_id;
var fanhome_gigya_id;
var gproxyLibrary;

export function NavBarApp(clientArg) {
    document.getElementsByTagName('body')[0].style.overflow = 'hidden';

    AddLibrary('https://static.zdassets.com/zendesk_app_framework_sdk/2.0/zaf_sdk.min.js');
    client = clientArg;
    client.context().then(context => {
       instanceGuid = context.instanceGuid;
    });
    client.metadata().then(function(metadata) {
        console.log('Metadata settings: ', metadata.settings);
        localStorage.setItem('api_url', metadata.settings.API_URL);
        localStorage.setItem('secret_key', metadata.settings.secret_key);
        pwAPIkey = metadata.settings.Partwork_API_key;
        fhAPIkey = metadata.settings.Fanhome_API_key;
        msAPIkey = metadata.settings.Model_Space_API_key;
        if (pwAPIkey || fhAPIkey || msAPIkey) {
          localStorage.setItem('nav.' + instanceGuid + '.pw_api_key', pwAPIkey);
          localStorage.setItem('nav.' + instanceGuid + '.fh_api_key', fhAPIkey);
          
        } else {
            renderAPIRequestError('No valid API key found. Ask an admin user to set it.'); 
        } 

        gproxyLibrary = metadata.settings.API_URL + pwAPIkey;
        
        var addLibraryCallback = () => {
            gproxy(null, function() {
              showUserSearch();
            })
        }
        AddLibrary(gproxyLibrary, addLibraryCallback);
    });

    

}

function showUserSearch() {
  const container = document.querySelector('.main');
  
  render(
    <ThemeProvider theme={{ ...DEFAULT_THEME }}>
        <div></div>
        <Grid style={{padding:"15px"}} justifyContent='center'>
          <Row justifyContent="start">
            <Col sm={3} alignSelf="end">
              <Field>
                  <Label>Email</Label>
                  <Input id="searchEmail" name="searchEmail" onChange={() => {validateEmail("searchEmail", "searchButton");}}/>
                  <MD id="searchEmailValidateMessage"></MD>
              </Field>
            </Col>
            <Col sm={2} alignSelf="end">
              <Button id="searchButton" onClick={searchEmail}>Search</Button>
            </Col>
          </Row>
          <Row justifyContent="start">
            <MD id="searchButtonMessage" style={{padding:"15px"}}></MD>
          </Row>         
        </Grid>
  </ThemeProvider>,
  container
  );
}


export const ShowNewUserForm = () => {
  var email = document.getElementById('searchEmail').value;
  const [radioValue, setRadioValue] = useState('FH');
  
  return (
    <ThemeProvider theme={{ ...DEFAULT_THEME }}>
        <div></div>
        <XL></XL>
        <XL style={{padding:"15px", paddingBottom:'3px'}}>Create New User</XL>
        <SM style={{color:'grey', paddingLeft:'15px'}}>*: mandatory field</SM>
        <XL></XL>
        <Grid style={{padding:"15px"}} justifyContent='center'>
          <Row justifyContent="start">
            <Col sm={1.5} alignSelf="start">
              <MD style={{fontWeight:'bold'}}>Contact & location</MD>
            </Col>
            <Col sm={2} alignSelf="start">
              <Field>
                <Label>Choose Locale *</Label>
                <Select id='chooseLocale'>              
                  <option key="N/A" value="-" defaultValue>-</option>
                  <option key="gr" value="gr">GR</option>
                  <option key="nl" value="nl">NL</option>
                  <option key="gb" value="gb">UK</option>
                  <option key="us" value="us">US</option>
                  <option key="cz" value="cz">CZ</option>
                  <option key="sk" value="sk">SK</option>
                  <option key="it" value="it">IT</option>
                  <option key="fr" value="fr">FR</option>
                  <option key="de" value="de">DE</option>
                  <option key="at" value="at">AT</option>
                  <option key="pl" value="pl">PL</option>
                </Select>
                <MD id="localeValidateMessage"></MD>
              </Field>            
            </Col>
            <Col sm={3} alignSelf="start">
              <Field>
                  <Label>Email *</Label>
                  <Input defaultValue={email} id="email" name="email" onChange={() => {validateEmail("email", "saveButton");}}/>
                  <MD id="emailValidateMessage"></MD>
              </Field>
            </Col>
            <Col sm={1.5} alignSelf="start">
              <Field>
                <Label>Brand *</Label>
                <div role="group" aria-label="Choose a brand">
                  <Field>
                    <Radio
                      name="brand"
                      value="FH"
                      checked={radioValue === 'FH'}
                      onChange={event => setRadioValue(event.target.value)}
                    >
                      <Label>Fanhome</Label>
                    </Radio>
                  </Field>
                  <Field>
                    <Radio
                      name="brand"
                      value="PW"
                      checked={radioValue === 'PW'}
                      onChange={event => setRadioValue(event.target.value)}
                    >
                      <Label>Partwork</Label>
                    </Radio>
                  </Field>
                </div>
                <MD id='brandValidateMessage'></MD>
              </Field>
            </Col>
          </Row>
          <Row justifyContent="start" style={{padding:"15px", paddingLeft:'0'}}>
            <Col sm={1.5} alignSelf="start">
              <MD style={{fontWeight:'bold'}}>Personal Information</MD>
            </Col>
            <Col sm={3} alignSelf="start">
              <Field>
                  <Label>First Name *</Label>
                  <Input name="firstName"/>
                  <MD id="firstNameValidateMessage"></MD>
              </Field>
            </Col>
            <Col sm={3} alignSelf="start">
              <Field>
                  <Label>Last Name *</Label>
                  <Input name="lastName"/>
                  <MD id="lastNameValidateMessage"></MD>
              </Field>
            </Col>
          </Row>
          <Row justifyContent="start" style={{padding:"15px", paddingLeft:'0'}}>
            <Col sm={1.5} alignSelf="start">
              <MD style={{fontWeight:'bold'}}>Privacy Agreement</MD>
            </Col>
            <Col sm={3} alignSelf="start" style={{padding:"5px", paddingBottom:'0'}}>
              <Field>
                <Checkbox defaultChecked={false} name="GDPRPromo">
                <Label>GDPR Promo Consent</Label>
                </Checkbox>
              </Field>
            </Col>
            <Col sm={3} alignSelf="start" style={{padding:"5px", paddingBottom:'0'}}>
              <Field>
                <Checkbox defaultChecked={false} name="GDPR3rd">
                <Label>GDPR 3rd Consent</Label>
                </Checkbox>
              </Field>
            </Col>
          </Row>
          <Row justifyContent="start" style={{padding:"15px", paddingLeft:'0'}}>
            <Col sm={1.5} alignSelf="start">
              <MD></MD>
            </Col>
            <Col sm={3} alignSelf="start" style={{padding:"5px"}}>
              <Field>
                  <Checkbox defaultChecked={false} name="GDPRProfiling">
                  <Label>GDPR Profiling Consent</Label>
                  </Checkbox>
              </Field>
            </Col>
            <Col sm={3} alignSelf="start" style={{padding:"5px"}}>
              <Field>
                  <Checkbox defaultChecked={false} name="GDPRsms">
                  <Label>GDPR SMS Consent</Label>
                  </Checkbox>
              </Field>
            </Col>
          </Row>
          <StyledDiv>
              <Button id="saveButton" onClick={() => createNewUser()}>Create</Button>
              <MD id='saveButtonMessage'></MD>
          </StyledDiv>
          
          </Grid>
  </ThemeProvider>
  );  
}

function createNewUser() {
  var validForm = true;

  var email = document.getElementsByName('email')[0].value;
  if(!email || email === '') {
    document.getElementById('emailValidateMessage').style.color = 'red';
    document.getElementById('emailValidateMessage').innerHTML = 'Mandatory field';
    validForm = false;
  } else {
    document.getElementById('emailValidateMessage').innerHTML = '';
  }

  var password = gproxy.security.random();

  var localeEl = document.getElementById('chooseLocale');
  var locale = localeEl.options[localeEl.selectedIndex].text;
  if(!locale || locale === '-') {
    document.getElementById('localeValidateMessage').style.color = 'red';
    document.getElementById('localeValidateMessage').innerHTML = 'Mandatory field';
    validForm = false;
  } else {
    document.getElementById('localeValidateMessage').innerHTML = '';
  }

  var firstName = document.getElementsByName('firstName')[0].value;
  if(!firstName || firstName === '') {
    document.getElementById('firstNameValidateMessage').style.color = 'red';
    document.getElementById('firstNameValidateMessage').innerHTML = 'Mandatory field';
    validForm = false;
  } else {
    document.getElementById('firstNameValidateMessage').innerHTML = '';
  }

  var lastName = document.getElementsByName('lastName')[0].value;
  if(!lastName || lastName === '') {
    document.getElementById('lastNameValidateMessage').style.color = 'red';
    document.getElementById('lastNameValidateMessage').innerHTML = 'Mandatory field';
    validForm = false;
  } else {
    document.getElementById('lastNameValidateMessage').innerHTML = '';
  }

  var gproxyLibrary;

  var addLibraryCallback = () => {
    registerInit(email, password);
  }

  document.getElementsByName('brand').forEach(
    function(item) {
      if(item.checked) {
        if(item.value === 'FH') {
          document.getElementById('brandValidateMessage').innerHTML = '';
          var user_api_key = localStorage.getItem('nav.' + instanceGuid + '.fh_api_key');
          gproxyLibrary = localStorage.getItem('api_url') + user_api_key;
        } else if(item.value === 'PW') {
          document.getElementById('brandValidateMessage').innerHTML = '';
          var user_api_key = localStorage.getItem('nav.' + instanceGuid + '.pw_api_key');
          gproxyLibrary = localStorage.getItem('api_url') + user_api_key;
        } else {
          document.getElementById('brandValidateMessage').style.color = 'red';
          document.getElementById('brandValidateMessage').innerHTML = 'Mandatory field';
          validForm = false;
        }
      }
    }
  )

  if(validForm) {
    changeEndpoint(gproxyLibrary, addLibraryCallback);
  } else {
    return;
  }

}

function registerInit(email, pass) {
  gproxy.accounts.initRegistration({
      'callback': function(res) {
        registerUser(email, pass, res.regToken);
        
        setTimeout(function() {
          document.getElementById('saveButtonMessage').innerHTML = "";
          window.location.reload();
        }, 3000);
      }
  });
}

function registerUser(email, pass, token) {
  var brandCode;
  document.getElementsByName('brand').forEach(
    function(item) {
      if(item.checked) {
        if(item.value === 'FH') {
          brandCode = 'FH';
        } else {
          brandCode = 'PW';
        }
      }
    }
  )
  var localeEl = document.getElementById('chooseLocale');
  var locale = localeEl.options[localeEl.selectedIndex].text;

  var storeCode;
  if (locale === 'GB') {
    storeCode = brandCode + 'UK';
  } else {
    storeCode = brandCode + locale;
  }

  var prefs = gproxy.consents.serialize({
      'profile': "default",
      'input': {
        'GDPRPromo': document.getElementsByName('GDPRPromo')[0].checked,
        'GDPRPromo3rd': document.getElementsByName('GDPR3rd')[0].checked,
        'GDPRProfiling': document.getElementsByName('GDPRProfiling')[0].checked,
        'GDPROptInSMS': document.getElementsByName('GDPRsms')[0].checked,
      }
  });
  console.warn("Serialized consents", prefs);
  var subs = {};
  gproxy.accounts.register({
      'email': email,
      'password': pass,
      'regToken': token,
      'finalizeRegistration': true,
      'preferences': prefs,
      'subscriptions': subs,
      'profile': {
        'firstName': document.getElementsByName('firstName')[0].value,
        'lastName': document.getElementsByName('lastName')[0].value,
        'locale': locale
      },
      'data': {
          'acquisitionSource': 'AGENT',
          'acquisitionOwner': storeCode,
          'identityType': 2,
          'lastSysModBy': 'ZD'
      },
      'callback':function(res) {
        console.log(res);
        if(res.errorCode === 0) {
          document.getElementById('saveButtonMessage').innerHTML = "Data updated successfully! Close the modal to see changes.";
          window.location.reload;
        } else {
          document.getElementById('saveButtonMessage').style.color = 'red';
          document.getElementById('saveButtonMessage').innerHTML = "Account creation failed: " + res.validationErrors[0].message;
        }
      }
  });
}

export function AddLibrary(urlOfTheLibrary, onLoad) {
  const script = document.createElement('script');
  if(onLoad){
    script.onload = onLoad;
  }
  if(urlOfTheLibrary.includes("gproxy.js")) {
    script.id = 'gproxyLib';
  }
  script.src = urlOfTheLibrary;
  script.type = "text/javascript";
  script.async = false;
  document.body.appendChild(script);
}

function changeEndpoint(newUrl, addLibraryCallback) {
  document.getElementById('gproxyLib').src = newUrl;
  addLibraryCallback();
}

function searchEmail() {
  var email = document.getElementById('searchEmail').value;
  if(email === '') {
    document.getElementById('searchButtonMessage').style.color = 'red';
    document.getElementById('searchButtonMessage').innerHTML = "Invalid search. Write an email address.";
    return;
  }

  var settings = {
    url: `/api/v2/search.json?query=type:user email:${email}`,
    type: 'GET',
    dataType: 'json',
    contentType: 'application/json'
  }

  client.request(settings).then(
    function(data) {
      var userExists;
      if(data.results[0]) {
        data.results.forEach(function(user) {
          if(user.email === email) {
            userExists = true;
            var userId = data.results[0].id;
            document.getElementById('searchButtonMessage').style.color = 'blue';
            document.getElementById('searchButtonMessage').innerHTML = "";
            document.getElementById('searchButtonMessage').innerHTML += "User already exists. Click here to go to their page: <a href='" + client._origin + "/agent/users/" + userId + "' target='_blank'>" + email + "</a>";
          }
        })
      }

      var callbackRender = (largerContainer) => {
        render (
          <ShowNewUserForm />,
          largerContainer
        );
      }

      if (!userExists) {
        document.getElementById('searchButtonMessage').innerHTML = "";
        document.getElementById('searchButtonMessage').style.color = 'blue';
        document.getElementById('searchButtonMessage').innerHTML = "User does not exist. Create one below.";
        var newUserForm = document.getElementById('newUserForm');
        if(!newUserForm) {
          const container = document.querySelector('.main');
          const newUser = document.createElement("div");
          newUser.id = "newUserForm";
          const largerContainer = container.appendChild(newUser);
          callbackRender(largerContainer);
        }
        
      }
    }
  );

}

function validateEmail(emailId, buttonId) {
  var email = document.getElementById(emailId).value;
  document.getElementById(buttonId + 'Message').innerHTML = "";
  var mailformat = /^([A-Za-z0-9_\-.!#$%&'*+/=?^`{|}~])+\@([A-Za-z0-9\-])+\.([A-Za-z]{2,4})$/;

  if (email.match(mailformat)) {
    document.getElementById(buttonId).disabled = false;
    document.getElementById(emailId + 'ValidateMessage').innerHTML = "";
  } else {
    document.getElementById(emailId + 'ValidateMessage').style.color = 'red';
    document.getElementById(emailId + 'ValidateMessage').innerHTML = "You have entered an invalid email address!";
    document.getElementById(buttonId).disabled = true;
  }
}
