import React, { useState } from 'react';
import { render } from 'react-dom';
import { Button } from '@zendeskgarden/react-buttons';
import { ThemeProvider, DEFAULT_THEME } from '@zendeskgarden/react-theming';
import { Field, Label, Checkbox, Input, Message } from '@zendeskgarden/react-forms';
import { Grid, Row, Col } from '@zendeskgarden/react-grid';
import styled from 'styled-components';
import { SM, MD, LG, XL, XXL, XXXL, Code } from '@zendeskgarden/react-typography';
import $ from 'jquery';
import { func } from 'prop-types';

const StyledDiv = styled.div`
  margin-top: ${p => p.theme.space.lg};
`;

var client;

var parentClient;

var parentInstanceGuid;

function parseParams(param_string){
  var param_sub = param_string.replace('#','').split('&');
  var param_obj = param_sub.reduce(function(memo, k){
    var kv = k.split('=');
    memo[kv[0]] = kv[1];
    return memo;
  }, {});
  return param_obj;  //Might be overbuilt but I like it because it returns a very pretty object
};

function getParentClient(parent_guid) {  //Definitely redundant but w/e
  return client.instance(parent_guid)
}

function renderAPIRequestError(error) {
  var params = parseParams(window.location.hash);
  
  parentInstanceGuid = params.parent_guid;

  const container = document.querySelector('.main');
  var errorMessage;

  if(error.includes("account not found")) {
    errorMessage = "No account was found for this requester. If needed, create an account for them.";
    renderNewUserButton(parentInstanceGuid);
  } else {
    errorMessage = error;
  
    render (
      <ThemeProvider theme={{ ...DEFAULT_THEME }}>
        <StyledDiv>
          <LG hue="red">An error occurred while trying to fetch this user's data:</LG>
          <MD hue="red">{errorMessage}</MD>
        </StyledDiv>
      </ThemeProvider>,
      container
    );
  }
}

function renderNewUserButton(parentInstanceGuid) {
  var ticket_user_id = localStorage.getItem('ticket.' + parentInstanceGuid + '.requester_id');
  var user_id = localStorage.getItem('user.' + parentInstanceGuid + '.user_id');

  if (ticket_user_id) {
    var settings = {
      url: '/api/v2/users/' + ticket_user_id,
      type: 'GET',
      dataType: 'json',
      contentType: 'application/json'
    };
  
    client.request(settings).then(
      function(res) {
        console.trace("renderNewUserButton", res);
  
        var country = localStorage.getItem('ticket.' + parentInstanceGuid + '.country');
  
        if(country === "null") {
          render (
            <ThemeProvider theme={{ ...DEFAULT_THEME }}>
              <StyledDiv>
                <LG>In order to create and account, you need to first select a valid country for this ticket.</LG>
                <Button disabled>Create new user</Button>
              </StyledDiv>
            </ThemeProvider>,
            container
          );
        } else {
          showNewUserForm(res.user);
        }
      },
      function(res) {
        console.error("ERROR: function {renderNewUserButton} encountered an error while tryig to get user information.", res);
      }
    );
  } else if(user_id) {
    var settings = {
      url: '/api/v2/users/' + user_id,
      type: 'GET',
      dataType: 'json',
      contentType: 'application/json'
    };
  
    client.request(settings).then(
      function(res) {
        console.trace("showEmptyNewUserForm", res);
        showEmptyNewUserForm(res.user);
      },
      function(res) {
        console.error("ERROR: function {renderNewUserButton} encountered an error while tryig to get user information.", res);
      }
    );
  } else {
    showEmptyNewUserForm();
  }
  
}

function showNewUserForm(userInfo) {
  const container = document.querySelector('.main');
  const brand = localStorage.getItem('ticket.' + parentInstanceGuid + '.brand');
  const locale = getLocaleFromCountry();
  const fullName = userInfo.name;
  const fullNameArray = fullName.split(' ');
  const firstName = fullNameArray[0];
  const lastName = fullNameArray[fullNameArray.length - 1];
  const email = userInfo.email;

  
  render(
    <ThemeProvider theme={{ ...DEFAULT_THEME }}>
          <div></div>
          <XL></XL>
          <XL>Identification details</XL>
          <XL></XL>
          <Grid>
            <Row justifyContent="start">
              <Col sm={2} alignSelf="center">
                <Field>
                  <Label>Locale</Label>
                  <Input value={locale} name="locale" readOnly/>
                </Field>
              </Col>
		          <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Email</Label>
                  <Input defaultValue={email} name="email" readOnly/>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Brand</Label>
                  <Input defaultValue={brand} name="brand" readOnly/>
                </Field>
              </Col>
            </Row>
            <Row justifyContent="start">
              <Col sm={4} alignSelf="center">
                <Field>
                  <Label>First Name</Label>
                  <Input defaultValue={firstName} name="firstName"/>
                </Field>
              </Col>
		          <Col sm={8} alignSelf="center">
                <Field>
                  <Label>Last Name</Label>
                  <Input defaultValue={lastName} name="lastName"/>
                </Field>
              </Col>
            </Row>
            <Row justifyContent="start">
              <Col sm={3} alignSelf="center">
                <Field>
                  <Checkbox defaultChecked={false} name="GDPRPromo">
                    <Label>GDPR Promo Consent</Label>
                  </Checkbox>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Checkbox defaultChecked={false} name="GDPR3rd">
                    <Label>GDPR 3rd Consent</Label>
                  </Checkbox>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Checkbox defaultChecked={false} name="GDPRProfiling">
                    <Label>GDPR Profiling Consent</Label>
                  </Checkbox>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Checkbox defaultChecked={false} name="GDPRsms">
                    <Label>GDPR SMS Consent</Label>
                  </Checkbox>
                </Field>
              </Col>
            </Row>
            <StyledDiv>
              <Button onClick={createNewUser}>Create</Button>
              <MD id='savingMessage'></MD>
            </StyledDiv>
            
          </Grid>
    </ThemeProvider>,
    container
  );
}

function showEmptyNewUserForm(userInfo) {
  const container = document.querySelector('.main');
  const fullName = userInfo.name;
  const fullNameArray = fullName.split(' ');
  const firstName = fullNameArray[0];
  const lastName = fullNameArray[fullNameArray.length - 1];
  const email = userInfo.email;
  var locale = localStorage.getItem('user.'+ parentInstanceGuid + '.locale');
  var brand = localStorage.getItem('user.' + parentInstanceGuid + '.request_brand');

  render(
    <ThemeProvider theme={{ ...DEFAULT_THEME }}>
          <div></div>
          <XL></XL>
          <XL>Identification details</XL>
          <XL></XL>
          <Grid>
            <Row justifyContent="start">
              <Col sm={2} alignSelf="center">
                <Field>
                  <Label>Locale</Label>
                  <Input defaultValue={locale} name="locale" readOnly/>
                </Field>
              </Col>
		          <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Email</Label>
                  <Input defaultValue={email} name="email" readOnly/>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Brand</Label>
                  <Input defaultValue={brand} name="brand" readOnly/>
                </Field>
              </Col>
            </Row>
            <Row justifyContent="start">
              <Col sm={4} alignSelf="center">
                <Field>
                  <Label>First Name</Label>
                  <Input defaultValue={firstName} name="firstName"/>
                </Field>
              </Col>
		          <Col sm={8} alignSelf="center">
                <Field>
                  <Label>Last Name</Label>
                  <Input defaultValue={lastName} name="lastName"/>
                </Field>
              </Col>
            </Row>
            <Row justifyContent="start">
              <Col sm={3} alignSelf="center">
                <Field>
                  <Checkbox defaultChecked={false} name="GDPRPromo">
                    <Label>GDPR Promo Consent</Label>
                  </Checkbox>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Checkbox defaultChecked={false} name="GDPR3rd">
                    <Label>GDPR 3rd Consent</Label>
                  </Checkbox>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Checkbox defaultChecked={false} name="GDPRProfiling">
                    <Label>GDPR Profiling Consent</Label>
                  </Checkbox>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Checkbox defaultChecked={false} name="GDPRsms">
                    <Label>GDPR SMS Consent</Label>
                  </Checkbox>
                </Field>
              </Col>
            </Row>
            <StyledDiv>
              <Button onClick={() => createNewUser()}>Create</Button>
              <MD id='savingMessage'></MD>
            </StyledDiv>
            
          </Grid>
    </ThemeProvider>,
    container
  );
}

export function ModalUserApp(clientArg) {
	
  AddLibrary('https://static.zdassets.com/zendesk_app_framework_sdk/2.0/zaf_sdk.min.js');
  
  client = clientArg;
    
  var params = parseParams(window.location.hash); //We start the modal client, then parse any parameters in the url
  // uso lo stesso client del ticket
  
  parentInstanceGuid = params.parent_guid;
  
  parentClient = getParentClient(parentInstanceGuid); //Hopefully this includes the parent_guid we want to send when creating modals
  
  var api_key = localStorage.getItem('ticket.' + parentInstanceGuid + '.api_key');
  var gigya_id = localStorage.getItem('ticket.' + parentInstanceGuid + '.gigya_id');

  var brand = localStorage.getItem('user.' + parentInstanceGuid + '.request_brand');
  if (!gigya_id) {
    if(brand === "FH") {
      gigya_id = localStorage.getItem('user.' + parentInstanceGuid + '.fanhome_gigya_id');
    } else {
      gigya_id = localStorage.getItem('user.' + parentInstanceGuid + '.partwork_gigya_id');
    }
  }
	
  var gproxyLibrary;
  if(api_key) {
    gproxyLibrary = localStorage.getItem('api_url') + api_key;
  } else if(brand === "FH") {
    var user_api_key = localStorage.getItem('user.' + parentInstanceGuid + '.fh_api_key');
    gproxyLibrary = localStorage.getItem('api_url') + user_api_key;
  } else {
    var user_api_key = localStorage.getItem('user.' + parentInstanceGuid + '.pw_api_key');
    gproxyLibrary = localStorage.getItem('api_url') + user_api_key;
  }

  var userInfo = null;
  var editedFields = {};
  
  var onLoad = function() {

    const container = document.querySelector('.main');

    var populateProperty = function (name, value) {
      var properties = name.split('.');

      var field = editedFields;

      for(var i=0; i<properties.length-1; i++) {
        if(!field[properties[i]]) {
          field[properties[i]] = {};
        }
        field = field[properties[i]];
      }

      field[properties[properties.length-1]] = value;
    }

    var onTextFieldChangeObject = function (e) {
      var name;
      if(e.target?.name) {
        name = e.target.name;
      populateProperty(name, e.target.value);   
      } else {
        name = e.name;
        populateProperty(name, e.value);
      }         
      document.getElementById('saveButton').disabled = false;   
    }

    var onCheckboxFieldChangeObject = function (e) {
      var name = e.target.name;
      populateProperty(name, e.target.checked);
      document.getElementById('saveButton').disabled = false; 
    }

    getUserInfo(gigya_id, function(res) {

      console.log("[userDetails] Il risultato della chiamata getAccountInfo: ", res);	 
//      console.log("[userDetails] User ShippingData: "+JSON.stringify(res.data.shippingAddress,null,2));
      if (res.errorCode === 0) {
        console.log("[userDetails] This is user info: "+JSON.stringify(res.data,null,2));
//        console.trace(res);
        userInfo = res;
        var normCountryCode=res.data.billingAddress.normCountryCode || localStorage.getItem('normCountryCode');
        console.log('[UserInfo] Normalized Country:'+normCountryCode)
        var valid=userInfo.isActive || userInfo.data.isActive;
        var privacy=(valid ? "" : "Note: the contact has requested the deletion of data, the profile will however remain visible for management of the history");
        var brandCode = userInfo.data.acquisitionOwner;
        var brandName;
        if(brandCode.includes('PW')) {
          brandName = 'PARTWORK';
        } else if (brandCode.includes('FH')) {
          brandName = 'FANHOME';
        } else if (brandCode.includes('MS')) {
          brandName = 'MODEL SPACE';
        } else {
          brandName = 'UNKNOWN';
        }

      render (
        <ThemeProvider theme={{ ...DEFAULT_THEME }}>
          
          <Grid>
          <Row justifyContent="start">
              <Col alignSelf='left'>
                <div style={{color:"red"}}>
                  {privacy}
                </div>
              </Col>
            </Row>
            <Row justifyContent="start">
              <Col sm={6} alignSelf="center">
                <div style={{padding: '15px'}}>
                <XL></XL>
                <XL>Identification details</XL>
                <XL></XL>
                </div>
              </Col>
              <Col sm={6} alignSelf="center">
                <div style={{padding: '15px'}}>
                <XL></XL>
                <XL>Profile details - Brand: {brandName}</XL>
                <XL></XL>
                </div>
              </Col>              
            </Row>
            <Row justifyContent="start">
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Identification Code</Label>
                  <Input defaultValue={userInfo.data.identityId} readOnly/>
                </Field>
              </Col>
		          <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Email</Label>
                  <Input defaultValue={userInfo.profile.email} name={"profile.email"} onChange={onTextFieldChangeObject} readOnly/>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>First Name</Label>
                  <Input defaultValue={userInfo.profile.firstName} name="profile.firstName" onChange={onTextFieldChangeObject}/>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Last Name</Label>
                  <Input defaultValue={userInfo.profile.lastName} name="profile.lastName" onChange={onTextFieldChangeObject}/>
                </Field>
              </Col>
            </Row>
          </Grid>
          <div style={{padding: '15px'}}>
          <XL></XL>
          <XL>Billing details</XL>
          <XL></XL>
          </div>          
          <Grid>
            <Row justifyContent="start">
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>First Name</Label>
                  <Input defaultValue={userInfo.data.billingAddress?.firstName} name="data.billingAddress.firstName" onChange={onTextFieldChangeObject}/>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Middle Name</Label>
                  <Input defaultValue={userInfo.data.billingAddress?.middleName} name="data.billingAddress.middleName" onChange={onTextFieldChangeObject}/>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Last Name</Label>
                  <Input defaultValue={userInfo.data.billingAddress?.lastName} name="data.billingAddress.lastName" onChange={onTextFieldChangeObject}/>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Phone Number</Label>
                  <Input defaultValue={userInfo.data.billingAddress?.phoneNumber} name="data.billingAddress.phoneNumber" onChange={onTextFieldChangeObject}/>
                </Field>
              </Col>
            </Row>
            
            <Row justifyContent="start">
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Address Line 1</Label>
                    <Input id='addressLine1' defaultValue={userInfo.data.billingAddress?.addressLine1} name="data.billingAddress.addressLine1" onChange={onTextFieldChangeObject}/>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>City</Label>
                    <Input id='city' defaultValue={userInfo.data.billingAddress?.city} name="data.billingAddress.city" onChange={onTextFieldChangeObject}/>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Country</Label>
                    <Input id='country' defaultValue={normCountryCode || userInfo.data.billingAddress?.normCountryCode} name="data.billingAddress.normCountryCode" onChange={onTextFieldChangeObject}/>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>County</Label>
                    <Input id='county' defaultValue={userInfo.data.billingAddress?.county} name="data.billingAddress.county" onChange={onTextFieldChangeObject}/>
                </Field>
              </Col>
            </Row>
			
            <Row justifyContent="start">              
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>State</Label>
                    <Input id='state' defaultValue={userInfo.data.billingAddress?.state} name="data.billingAddress.state" onChange={onTextFieldChangeObject}/>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>Postal code</Label>
                    <Input id='zipCode' defaultValue={userInfo.data.billingAddress?.postalCode} name="data.billingAddress.postalCode" onChange={onTextFieldChangeObject}/>
                </Field>
              </Col>
            </Row>
          </Grid>
          <div style={{padding: '15px'}}>
          <XL></XL>
          <XL>Account details</XL>
          <XL></XL>
          </div>
          <Grid>
            <Row justifyContent="start">
              <Col sm={3} alignSelf="center">
              <Field>
                <Label>Tax Code</Label>
                <Input defaultValue={userInfo.data.billingAddress?.taxCode} name="data.billingAddress.taxCode" onChange={onTextFieldChangeObject}/>
              </Field>
              </Col>
              <Col sm={3} alignSelf="center">
              <Field>
                <Label>VAT Code</Label>
                <Input defaultValue={userInfo.data.billingAddress?.VATCode} name="data.billingAddress.VATCode" onChange={onTextFieldChangeObject}/>
              </Field>
              </Col>
              <Col sm={3} alignSelf="center">
              <Field>
                <Label>SDI</Label>
                <Input defaultValue={userInfo.data.billingAddress?.SDI} name="data.billingAddress.SDI" onChange={onTextFieldChangeObject}/>
              </Field>
              </Col>
              <Col sm={3} alignSelf="center">
              <Field>
                <Label>Certified Email</Label>
                <Input defaultValue={userInfo.data.billingAddress?.emailCertified} name="data.billingAddress.emailCertified" onChange={onTextFieldChangeObject}/>
              </Field>
              </Col>
            </Row>
          </Grid>		  
          <div style={{padding: '15px'}}>
          <XL></XL>
          <XL>GDPR consent details</XL>
          <XL></XL>
          </div>
          <Grid>
            <Row justifyContent="start">
              <Col sm={3} alignSelf="center">
                <Field>
                  <Checkbox defaultChecked={userInfo.preferences.GDPRPromo?.isConsentGranted} name="preferences.GDPRPromo.isConsentGranted" onChange={onCheckboxFieldChangeObject}>
                    <Label>GDPR Promo Consent</Label>
                  </Checkbox>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>GDPR Promo Consent Modified</Label>
                  <Input defaultValue={userInfo.preferences.GDPRPromo?.lastConsentModified ? new Date(userInfo.preferences.GDPRPromo?.lastConsentModified).toLocaleDateString("it-IT") : "N/A"} readOnly/>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
              <Field>
                  <Checkbox defaultChecked={userInfo.preferences.GDPRPromo3rd?.isConsentGranted} name="preferences.GDPRPromo3rd.isConsentGranted" onChange={onCheckboxFieldChangeObject}>
                    <Label>GDPR 3rd Consent</Label>
                  </Checkbox>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>GDPR 3rd Consent Modified</Label>
                  <Input defaultValue={userInfo.preferences.GDPRPromo3rd?.lastConsentModified ? new Date(userInfo.preferences.GDPRPromo3rd?.lastConsentModified).toLocaleDateString("it-IT") : "N/A"} readOnly/>
                </Field>
              </Col>
            </Row>
            <Row justifyContent="start">
              <Col sm={3} alignSelf="center">
                <Field>
                  <Checkbox defaultChecked={userInfo.preferences.GDPRProfiling?.isConsentGranted} name="preferences.GDPRProfiling.isConsentGranted" onChange={onCheckboxFieldChangeObject}>
                    <Label>GDPR Profiling Consent</Label>
                  </Checkbox>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>GDPR Profiling Consent Modified</Label>
                  <Input defaultValue={userInfo.preferences.GDPRProfiling?.lastConsentModified ? new Date(userInfo.preferences.GDPRProfiling?.lastConsentModified).toLocaleDateString("it-IT") : "N/A"} readOnly/>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Checkbox defaultChecked={userInfo.preferences.GDPROptInSMS?.isConsentGranted } name="preferences.GDPROptInSMS.isConsentGranted" onChange={onCheckboxFieldChangeObject}>
                    <Label>GDPR SMS Consent</Label>
                  </Checkbox>
                </Field>
              </Col>
              <Col sm={3} alignSelf="center">
                <Field>
                  <Label>GDPR SMS Consent Modified</Label>
                  <Input defaultValue={userInfo.preferences.GDPROptInSMS?.lastConsentModified ? new Date(userInfo.preferences.GDPROptInSMS?.lastConsentModified).toLocaleDateString("it-IT") : "N/A"} readOnly />
                </Field>
              </Col>
            </Row>
            <div style={{padding: '15px'}}>
              <Row justifyContent="end" alignItems="end">
                <Col sm={4} alignSelf="end" textAlign="end">
                  <Button id='saveButton' onClick={onSaveClicked}>Save</Button>
                  <MD id='savingMessage'></MD>
                </Col>
              </Row>
            </div>
          </Grid>
          </ThemeProvider>,
          container
      );

      } else {
        // Qui invece potete gestire il messaggio di errore dell'authenticate
        console.error("ERROR: Function {getAccountInfo} ran into an error while trying to execute", res);
        if(res.errorDetails.includes('missing paramater [handle]')) {
          renderNewUserButton(parentInstanceGuid);
        } else {
          renderAPIRequestError(res.errorDetails);
        }
      }
    });  
  };
  
  
  var onSaveClicked = function (e) {
    var onSaveLoad = function () {
	  
      var callback = function (res) {
        var saveButton=document.getElementById('saveButton');
        if(saveButton) {
            saveButton.disabled = true;
            saveButton.textContent = "Save";
            console.log("Il risultato della chiamata setAccountInfo: ", res);
            if (res.errorCode === 0) {
              saveButton.hidden = true;
            document.getElementById('savingMessage').innerHTML = "Data updated successfully!";

            setTimeout(function () {
              saveButton.hidden = false;
              saveButton.disabled = true;
              document.getElementById('savingMessage').innerHTML = "";
              window.location.reload();
            }, 3000);

          } else {
            console.error("ERROR: Function {setUserInfo} ran into an error while trying to execute ", res);
            renderAPIRequestError(res.errorDetails);
          }
        }
        else console.log('Failed to reset saveButton');
      }

      var gigyaId = localStorage.getItem('ticket.' + parentInstanceGuid + '.gigya_id');
      
      if (!gigyaId) {
        if(brand === "FH") {
          gigyaId = localStorage.getItem('user.' + parentInstanceGuid + '.fanhome_gigya_id');
        } else {
          gigyaId = localStorage.getItem('user.' + parentInstanceGuid + '.partwork_gigya_id');
        }
      }
      
      setUserInfo(gigyaId, editedFields, callback);
      
    }
	
    e.target.hidden = true;
    e.target.textContent = "Saving";

    AddLibrary(gproxyLibrary, onSaveLoad);
  }
  

  var setUserInfo = function (gigyaId, payload, onUserInfoUpdated) {
	  
	  var callback = function(res) {

      console.log("Il risultato della chiamata authenticate: ", res);
	  
      if (res.errorCode === 0) {
		  
        console.log("Oggetto inviato ad API setUserInfo: ");
		
        console.trace(payload);
		
		    var payloadCopy = $.extend({}, payload);

        payloadCopy.callback = onUserInfoUpdated;
        
        gproxy.accounts.setAccountInfo(payloadCopy);
        
		
      } else {

        console.error("ERROR: function {authenticate} ran into an error while trying to authenticate the user", res);
        renderAPIRequestError(res.errorDetails);
      }
    };
	
	  authenticate(gigyaId, callback);
	
  }

  AddLibrary(gproxyLibrary, onLoad);

}

var getUserInfo = function (gigyaId, onUserInfoLoaded) {
	  
  var callback = function(res) {
    console.log("[getUserInfo] Il risultato della chiamata authenticate: ", res);
  
    if (res.errorCode === 0) {
    
      gproxy.accounts.getAccountInfo({ "callback": onUserInfoLoaded });
  
    } else {
      console.error("ERROR: function {authenticate} ran into an error while trying to authenticate the user", res);
      if(res.errorDetails.includes('missing paramater [handle]')) {
        renderNewUserButton(parentInstanceGuid);
      } else {
        renderAPIRequestError(res.errorDetails);
      }
    }
  }

  authenticate(gigyaId, callback);

}

var authenticate = function (gigyaId, onAuthenticate) {
  var secret = localStorage.getItem('secret_key');
  gproxy(null, function() {
    gproxy.extension.install('gcustomer').then(() => {
      gproxy.protected.authenticate({
        "client": "zendesk-client",
        "secret": secret,
        "handle": gigyaId,
        "callback" : onAuthenticate,
        "persistent" : false,
        "shared": true
      });
    }).catch((error) => {
      console.error("Cannot load extension...", error);
    });
  });

} 

function getLocaleFromCountry() {
  
  var locale;
  var country = localStorage.getItem('ticket.' + parentInstanceGuid + '.country');
  console.log('[getLocale '+country);
  switch (country) {
    case "gr":
      locale = "el-GR";
      break;
    case "nl":
      locale = "nl-NL";
      break;
    case "uk":
      locale = "en-GB";
      break;
    case "gb":
      locale = "en-GB";
      break;
    case "us":
      locale = "en-US";
      break;
    case "cz":
      locale = "cz-CZ";
      break;
    case "sk":
      locale = "sk-SK";
      break;
    case "it":
      locale = "it-IT";
      break;
    case "fr":
      locale = "fr-FR";
      break;
    case "es":
      locale = "es-ES";
      break;
    case "de":
      locale = "de-DE";
      break;
    case "at":
      locale = "de-AT";
      break;
    case "pl":
      locale = "pl-PL";
      break;
  }

  return locale;
}

function createNewUser() {
  var email = document.getElementsByName('email')[0].value;
  var password = gproxy.security.random();
  registerInit(email, password);
}

function registerInit(email, pass) {
  gproxy.accounts.initRegistration({
      'callback': function(res) {
        registerUser(email, pass, res.regToken);
        
        setTimeout(function() {
          document.getElementById('savingMessage').innerHTML = "";
          window.location.reload();
        }, 3000);
      }
  });
}

function registerUser(email, pass, token) {
  var ticketBrand = localStorage.getItem('ticket.' + parentInstanceGuid + '.brand');
  var userBrand = localStorage.getItem('user.' + parentInstanceGuid + '.request_brand');
  var locale = document.getElementsByName('locale')[0].value;
  var localeArray = locale.split('-');
  var localeCode = localeArray[1];
  if (!localeCode) {
    localeCode = locale.toUpperCase();
  }
  
  var brand;
  var brandCode;
  if(ticketBrand) {
    brand = ticketBrand;
  } else if(userBrand) {
    brand = userBrand;
  }
  if (brand === "fanhome" || brand  === "FH") {
    brandCode = "FH";
  } else if (brand === "partwork" || brand === "PW") {
    brandCode = "PW";
  } else if (brand === "model_space"){
    // TO DO: inserire gestione per model space quando disponibile
  }
  
  var storeCode;
  if (localeCode === 'GB') {
    storeCode = brandCode + 'UK';
  } else {
    storeCode = brandCode + localeCode;
  }

  var prefs = gproxy.consents.serialize({
      'profile': "default",
      'input': {
        'GDPRPromo': document.getElementsByName('GDPRPromo')[0].checked,
        'GDPRPromo3rd': document.getElementsByName('GDPR3rd')[0].checked,
        'GDPRProfiling': document.getElementsByName('GDPRProfiling')[0].checked,
        'GDPROptInSMS': document.getElementsByName('GDPRsms')[0].checked,
      }
  });
  console.warn("Serialized consents", prefs);
  var subs = {};
  gproxy.accounts.register({
      'email': email,
      'password': pass,
      'regToken': token,
      'finalizeRegistration': true,
      'preferences': prefs,
      'subscriptions': subs,
      'profile': {
        'firstName': document.getElementsByName('firstName')[0].value,
        'lastName': document.getElementsByName('lastName')[0].value,
        'locale': locale
      },
      'data': {
          'acquisitionSource': 'AGENT',
          'acquisitionOwner': storeCode,
          'identityType': 2,
          'lastSysModBy': 'ZD'
      },
      'callback':function(res) {
        console.log(res);
        if(res.errorCode === 0) {
          document.getElementById('savingMessage').innerHTML = "Data updated successfully! Close the modal to see changes.";
        } else {
          document.getElementById('savingMessage').style.color = 'red';
          document.getElementById('savingMessage').innerHTML = "Account creation failed: " + res.validationErrors[0].message;
        }
      }
  });
}

export function AddLibrary(urlOfTheLibrary, onLoad) {
  const script = document.createElement('script');
  if(onLoad){
    script.onload = onLoad;
  }
  if(urlOfTheLibrary.includes("gproxy.js")) {
    script.id = 'gproxyLib';
  }
  script.src = urlOfTheLibrary;
  script.type = "text/javascript";
  script.async = false;
  document.body.appendChild(script);
}

function changeEndpoint(newUrl, callbackFunction) {
  document.getElementById('gproxyLib').src = newUrl;
  callbackFunction;
}