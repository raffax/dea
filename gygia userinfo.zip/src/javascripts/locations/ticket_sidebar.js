import { App } from "../modules/app";
import { ModalUserApp } from "../modules/userDetails";
import { ModalOrderApp } from "../modules/orderDetails";
import { UserSidebarApp } from "../modules/userSidebar";
import { NavBarApp } from "../modules/navBar";
import { ParseParams } from "../modules/helperFunctions";

/* global ZAFClient */
var client = ZAFClient.init()

client.get('requirement:pw_api_key').then(function(data) {
  console.log(data);
});

client.on('app.registered', function (appData) {
  if(appData.context.location === 'modal') {
    var params = ParseParams(window.location.hash);
  
    var modal_type = params.modal_type;

    if (modal_type === 'userDetails') {
      return new ModalUserApp(client, appData);
    } else if (modal_type === 'orderDetails') {
      return new ModalOrderApp(client, appData);
    } else {
      console.error('Modal type is not supported!');
    }
    
  } else if(appData.context.location === 'user_sidebar'){
    return new UserSidebarApp(client, appData);
  } else if(appData.context.location === 'nav_bar') {
    return new NavBarApp(client, appData);
  }
  return new App(client, appData)
})
