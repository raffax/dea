import React, { useState } from 'react';
import { render } from 'react-dom';
import { Button } from '@zendeskgarden/react-buttons';
import { ThemeProvider, DEFAULT_THEME } from '@zendeskgarden/react-theming';
import { Field, Label, Checkbox, Input, Message, Radio } from '@zendeskgarden/react-forms';
import { Grid, Row, Col } from '@zendeskgarden/react-grid';
import styled from 'styled-components';
import { SM, MD, LG, XL, XXL, XXXL, Code } from '@zendeskgarden/react-typography';

const StyledDiv = styled.div`
  margin-top: ${p => p.theme.space.lg};
`;


var client;
var instanceGuid;

var pwAPIkey;
var fhAPIkey;
var msAPIkey;

var partwork_gigya_id;
var fanhome_gigya_id;
var gproxyLibrary;

export function UserSidebarApp(clientArg) {
    document.getElementsByTagName('body')[0].style.overflow = 'hidden';

    AddLibrary('https://static.zdassets.com/zendesk_app_framework_sdk/2.0/zaf_sdk.min.js');
    client = clientArg;
    client.context().then(context => {
       instanceGuid = context.instanceGuid;
    });
    client.metadata().then(function(metadata) {
        console.log('Metadata settings: ', metadata.settings);
        localStorage.setItem('api_url', metadata.settings.API_URL);
        localStorage.setItem('secret_key', metadata.settings.secret_key);
        pwAPIkey = metadata.settings.Partwork_API_key;
        fhAPIkey = metadata.settings.Fanhome_API_key;
        msAPIkey = metadata.settings.Model_Space_API_key;
        if (pwAPIkey || fhAPIkey || msAPIkey) {
          localStorage.setItem('user.' + instanceGuid + '.pw_api_key', pwAPIkey);
          localStorage.setItem('user.' + instanceGuid + '.fh_api_key', fhAPIkey);
    
            getUserInfo();
        } else {
        renderAPIRequestError('No valid API key found. Ask an admin user to set it.'); 
        } 
    });
}

function getUserInfo() {
    var userId;

    client.get('user').then(
      function(userData) {
          userId = userData.user.id;
          localStorage.setItem('user.' + instanceGuid + '.user_id', userId);
          
          var settings = {
              url: '/api/v2/users/' + userId,
              type: 'GET',
              dataType: 'json',
              contentType: 'application/json'
          };
      
          client.request(settings).then(
          function(data) {
              var userFields = data.user.user_fields;
              localStorage.setItem('user.' + instanceGuid + '.locale', data.user.locale);

              if(userFields.fanhome_gigya_id) {
                  fanhome_gigya_id = userFields.fanhome_gigya_id;
                  localStorage.setItem('user.' + instanceGuid + '.fanhome_gigya_id', fanhome_gigya_id);
                  gproxyLibrary = localStorage.getItem('api_url') + localStorage.getItem('user.' + instanceGuid + '.fh_api_key');
              }
              if(userFields.partwork_gigya_id) {
                  partwork_gigya_id = userFields.partwork_gigya_id;
                  localStorage.setItem('user.' + instanceGuid + '.partwork_gigya_id', partwork_gigya_id);
                  gproxyLibrary = localStorage.getItem('api_url') + localStorage.getItem('user.' + instanceGuid + '.pw_api_key');
              }
              if(!userFields.fanhome_gigya_id && !userFields.partwork_gigya_id) {
                gproxyLibrary = localStorage.getItem('api_url') + localStorage.getItem('user.' + instanceGuid + '.pw_api_key');
              }
              AddLibrary(gproxyLibrary, addLibraryCallback);
          });
      }
  )

    var addLibraryCallback = () => {
      gproxy(null, function() {
        renderUserInfoButton();
      })
    }

    
}

function renderUserInfoButton() {
    const container = document.querySelector('.main');
  
    render (
      <ThemeProvider theme={{ ...DEFAULT_THEME }}>
        <div style={{overflow: 'hidden'}}>
          <Row justifyContent="center" style={{padding:'15px'}}>
            <Col sm={2} alignSelf="center" style={{padding:'5px'}}>
              <Button onClick={() => showUserModal("PW")} disabled={partwork_gigya_id ? false : true}>Partwork User info</Button>
            </Col>
            <Col sm={2} alignSelf="center" style={{padding:'5px'}}>
              <Button onClick={() => showUserModal("FH")} disabled={fanhome_gigya_id ? false : true}>Fanhome User info</Button>
            </Col>
          </Row>
          <Row justifyContent='center' style={{padding:'15px'}}>
            <Col sm={4} alignSelf='center'>
                <Button onClick={() => handleCreateNewUser(fanhome_gigya_id, partwork_gigya_id)} disabled={!fanhome_gigya_id || !partwork_gigya_id ? false : true}>Create New User</Button>
            </Col>
          </Row>
        </div>
      </ThemeProvider>,
      container
    );
    resize_app();
  }

  export const BrandChoice = () => {
    const [radioValue, setRadioValue] = useState('FH');

    return (
      <ThemeProvider theme={{ ...DEFAULT_THEME }}>
        <Col sm={1} alignSelf="start">
          <Field>
            <Label>Brand *</Label>
            <div role="group" aria-label="Choose a brand">
              <Field>
                <Radio
                  name="brand"
                  value="FH"
                  checked={radioValue === 'FH'}
                  onChange={event => setRadioValue(event.target.value)}
                >
                  <Label>Fanhome</Label>
                </Radio>
              </Field>
              <Field>
                <Radio
                  name="brand"
                  value="PW"
                  checked={radioValue === 'PW'}
                  onChange={event => setRadioValue(event.target.value)}
                >
                  <Label>Partwork</Label>
                </Radio>
              </Field>
            </div>
          </Field>
        </Col>
        <Col sm={1} alignSelf="start" style={{paddingTop:'5px'}}>
          <Button id='brandChoice' onClick={() => showUserModal(radioValue)}>Confirm</Button>
        </Col>
      </ThemeProvider>
    );
  }

  function handleCreateNewUser(fh_gigya_id, pw_gigya_id) {
    var callbackRender = (largerContainer) => {
      render (
        <BrandChoice />,
        largerContainer
      );
      resize_app();
    }

    if (!fh_gigya_id && !pw_gigya_id) {
      const container = document.querySelector('.main');
      const newUser = document.createElement("div");
      newUser.id = "chooseBrand";
      const largerContainer = container.appendChild(newUser);
      callbackRender(largerContainer);
    } else {
      if (!fh_gigya_id) {
        showUserModal("FH");
      } else {
        showUserModal("PW");
      }
    }
  }

  function showUserModal(brand) {
    debugger;
	localStorage.setItem('user.' + instanceGuid + '.request_brand', brand);
    // potrei usare direttamente instanceGuid, TODO da valutare
    client.context().then(context => {
        
      var parent_guid = context.instanceGuid;
      var options = {
          location: 'modal',
          url: 'assets/iframe.html#parent_guid=' + parent_guid + '&modal_type=userDetails',
          size: { // optional
            width: '1200px',
            height: '500px'
          }
      }
      client.invoke('instances.create', options).then(function(modalContext) {
          // The modal is on the screen now!
          var modalClient = client.instance(modalContext['instances.create'][0].instanceGuid);
          modalClient.on('modal.close', function() {
            // Modal has been closed
            console.log("Modal closed correctly");        
          });
      });	
    });  
  }

function resize_app() {
    let el = document.getElementsByTagName('body')[0];
    let height = el.offsetHeight;
    let style = getComputedStyle(el);
    height += parseInt(style.marginTop) + parseInt(style.marginBottom) + 20;
    client.invoke('resize', { width: '100%', height: height });
}

export function AddLibrary(urlOfTheLibrary, onLoad) {
    const script = document.createElement('script');
    if(onLoad){
      script.onload = onLoad;
    }
    if(urlOfTheLibrary.includes("gproxy.js")) {
      script.id = 'gproxyLib';
    }
    script.src = urlOfTheLibrary;
    script.type = "text/javascript";
    script.async = false;
    document.body.appendChild(script);
  }

