
export function ParseParams(param_string){
  var param_sub = param_string.replace('#','').split('&');
  var param_obj = param_sub.reduce(function(memo, k){
    var kv = k.split('=');
    memo[kv[0]] = kv[1];
    return memo;
  }, {});
  return param_obj;  //Might be overbuilt but I like it because it returns a very pretty object
};

