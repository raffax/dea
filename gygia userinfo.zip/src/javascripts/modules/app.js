import React, { useState } from 'react';
import { render } from 'react-dom';
import { Button } from '@zendeskgarden/react-buttons';
import { ThemeProvider, DEFAULT_THEME } from '@zendeskgarden/react-theming';
import { Field, Label, Checkbox, Input, Message } from '@zendeskgarden/react-forms';
import { Grid, Row, Col } from '@zendeskgarden/react-grid';
import styled from 'styled-components';
import { SM, MD, LG, XL, XXL, XXXL, Code } from '@zendeskgarden/react-typography';
import { Body, Cell, Head, HeaderCell, HeaderRow, Row as TableRow, Table } from '@zendeskgarden/react-tables';
import $ from 'jquery';

const StyledDiv = styled.div`
  margin-top: ${p => p.theme.space.lg};
`;

var client;

var instanceGuid;

var GIG_CF = {};

var GIG_CF_IdsArray;


var GIG_CF_Values = {
  "Brand" : null,
  "Country" : null
}

var apiURL;
var pwAPIkey;
var fhAPIkey;
var msAPIkey;

export function App (clientArg) {
  document.getElementsByTagName('body')[0].style.overflow = 'hidden';
  
  AddLibrary('https://static.zdassets.com/zendesk_app_framework_sdk/2.0/zaf_sdk.min.js');
  client = clientArg;
  client.context().then(context => {
    instanceGuid = context.instanceGuid;
  });
  client.metadata().then(function(metadata) {
    console.log('Metadata settings: ', metadata.settings);
    localStorage.setItem('api_url', metadata.settings.API_URL);
    localStorage.setItem('secret_key', metadata.settings.secret_key);
    localStorage.setItem('gaddress_api_url', metadata.settings.GADDRESS_API_URL);
    pwAPIkey = metadata.settings.Partwork_API_key;
    fhAPIkey = metadata.settings.Fanhome_API_key;
    msAPIkey = metadata.settings.Model_Space_API_key;
    if (pwAPIkey || fhAPIkey || msAPIkey) {
      getConnectionParameters(pwAPIkey, fhAPIkey, msAPIkey);
	  } else {
      renderAPIRequestError('No valid API key found. Ask an admin user to set it.'); 
    }  
  });
}

export function mapCustomFields(callback) {
  var settings = {
    url: '/api/v2/ticket_fields.json',
    type: 'GET',
    dataType: 'json',
    contentType: 'application/json'
  };

  client.request(settings).then(
    function (data) {
      GIG_CF = {
        "Brand" : 1,
        "Country": 2
      }
      GIG_CF_IdsArray = [];

      for (var i = 0; i < data.ticket_fields.length; i++) {
        var title = data.ticket_fields[i].title;
        var id = data.ticket_fields[i].id;
        
        for (const pName in GIG_CF) {
          if (pName === title) {
            GIG_CF[pName] = id;
            GIG_CF_IdsArray.push("ticket.customField:custom_field_" + id);
            break;
          }
        }
      }

      client.get(GIG_CF_IdsArray).then(
        function (data) {
          fillGIGCfValues(data);
          callback();
        },
        function(response) {
          console.error(response);
        }
      );
    },
    function (response) {
      console.error(response);
    }
  );
}

function getGigyaId(userId, callbackSuccess, callbackError) {  
  var settings = {
    url: '/api/v2/users/' + userId,
    type: 'GET',
    dataType: 'json',
    contentType: 'application/json'
  };

  client.request(settings).then(
    callbackSuccess,
    callbackError
  );
}

function getConnectionParameters(pwAPIkey, fhAPIkey, msAPIkey) {
  function callback() {
    var country = GIG_CF_Values["Country"];
    localStorage.setItem('ticket.' + instanceGuid + '.country', country);
    
    if (GIG_CF_Values["Brand"] != null) {
		
      var brand = GIG_CF_Values["Brand"];
      localStorage.setItem('ticket.' + instanceGuid + '.brand', brand);
	  
      if (brand === "fanhome") {
        if(fhAPIkey) {
          localStorage.setItem('ticket.' + instanceGuid + '.api_key', fhAPIkey);
        } else {
          renderAPIRequestError('No valid API key found for brand Fanhome. Ask an admin user to set it.');
        }
      } else if (brand === "partwork") {
        if(pwAPIkey) {
          localStorage.setItem('ticket.' + instanceGuid + '.api_key', pwAPIkey);
        } else {
          renderAPIRequestError('No valid API key found for brand Partwork. Ask an admin user to set it.');
        }
      } else if (brand === "model_space"){
        if(msAPIkey) {
          localStorage.setItem('ticket.' + instanceGuid + '.api_key', msAPIkey);
        } else {
          renderAPIRequestError('No valid API key found for brand Model Space. Ask an admin user to set it.');
        }
      }

      client.get(['ticket']).then(
        function(data) {

          var user_id = data.ticket.requester.id;
          localStorage.setItem('ticket.' + instanceGuid + '.requester_id', user_id);

          var callbackSuccess = function (user_info) {
            var userFields = user_info.user.user_fields;
            for (const field in userFields) {
              var brand = GIG_CF_Values["Brand"];
              if (brand === "fanhome") {
                localStorage.setItem('ticket.' + instanceGuid + '.gigya_id', userFields.fanhome_gigya_id);
              } else if (brand === "partwork") {
                localStorage.setItem('ticket.' + instanceGuid + '.gigya_id', userFields.partwork_gigya_id);
              } else if (brand === "model_space") {
                localStorage.setItem('ticket.' + instanceGuid + '.gigya_id', userFields.modelspace_gigya_id);
              }
            }

            renderMainFrame(instanceGuid);
          }

          var callbackError = function (response) {
            console.error(response);
          }
    
          var gigya_id = getGigyaId(user_id, callbackSuccess, callbackError);
        }
      );
    } else {
      console.error("ERROR: function {getBrandField} ran into an error while trying to fetch the value of the Brand field.");
      renderBrandVoidError();
    }
  }

  mapCustomFields(callback);
}

function fillGIGCfValues(data) {
  for (const pName in GIG_CF) {
    GIG_CF_Values[pName] = data["ticket.customField:custom_field_" + GIG_CF[pName]];
  }
  console.log("Custom fields' values:", GIG_CF_Values);
}

function renderMainFrame(instanceGuid) {
  var gigya_id = localStorage.getItem('ticket.' + instanceGuid + '.gigya_id');
  var api_key = localStorage.getItem('ticket.' + instanceGuid + '.api_key');
  var gproxyLibrary = localStorage.getItem('api_url') + api_key;
  
  var getUserInfoCallback = function(res) {

    console.log("Il risultato della chiamata getAccountInfo: ", res);	 

    if (res.errorCode === 0) {
      console.log("This is user info: ");
      console.trace(res);

      if(res.data.identityId) {
        getOrderList();
        localStorage.setItem('customerId', res.data.identityId);
      } else {
        console.log("No order found for this user!");
        renderUserInfoButton();
      }
      
    } else {
      // Qui invece potete gestire il messaggio di errore dell'authenticate
      console.error("ERROR: Function {getAccountInfo} ran into an error while trying to execute", res);
      renderAPIRequestError(res.errorDetails);
    }
  }

  var addLibraryCallback = () => getUserInfo(gigya_id, getUserInfoCallback);

  AddLibrary(gproxyLibrary, addLibraryCallback);
}

function renderUserInfoButton() {
  const container = document.querySelector('.main');

  render (
    <ThemeProvider theme={{ ...DEFAULT_THEME }}>
      <div style={{overflow: 'hidden'}}>
        <Row justifyContent="center">
          <Col alignSelf="center">
            <Button onClick={showUserModal}>User info</Button>
          </Col>
        </Row>
        <Row justifyContent="center">
          <StyledDiv>
            <MD>No orders were found for this user.</MD>
          </StyledDiv>
        </Row>
      </div>
    </ThemeProvider>,
    container
  );
  resize_app();
}

function getOrderList() {
  const container = document.querySelector('.main');
 
  gproxy.customer.order.list().then((list)=> {
    console.log("This is the order list", list);
    if(list.length === 0) {
      renderUserInfoButton();
    } else {
      render (
        <ThemeProvider theme={{ ...DEFAULT_THEME }}>
          <Row justifyContent="center">
            <Col alignSelf="center">
              <Button onClick={showUserModal}>User info</Button>
            </Col>
          </Row>
          <Row justifyContent="center">
            <div style={{ overflowX: 'hidden' }}>
              <div style={{ overflowY: 'hidden' }}>
                <Table>
                  <Head>
                    <HeaderRow>
                      <HeaderCell style={{width: '150px'}}>Order</HeaderCell>
                      <HeaderCell style={{width: '100px'}}>Reference</HeaderCell>
                      <HeaderCell>Status</HeaderCell>
                    </HeaderRow>
                  </Head>
                  <Body>
                    {list.map(data => (
                    <TableRow key={data.ref} onClick={() => showOrderModal(data)}>
                      <Cell style={{width: '150px'}}>{data.name}</Cell>
                      <Cell style={{width: '100px'}}>{data.ref}</Cell>
                      <Cell>{data.status}<div>({data.statusCode})</div></Cell>
                    </TableRow>
                    ))}
                  </Body>
                </Table>
              </div>
            </div>
          </Row>

        </ThemeProvider>,
        container
      );
      resize_app();
    }
  }).catch(error => {
    console.error("Cannot load order list...", error);
    renderAPIRequestError(error);
  });

}

function renderBrandVoidError() {
  const container = document.querySelector('.main');

  render (
    <ThemeProvider theme={{ ...DEFAULT_THEME }}>
      <Row justifyContent='center'>
        <Col alignSelf='start'>
          <Button disabled>User info</Button>
        </Col>
      </Row>
      <StyledDiv>
        <LG hue="red">Brand not selected: please select the proper brand and save the ticket.</LG>
      </StyledDiv>
    </ThemeProvider>,
    container
  );
  resize_app();
}

function renderAPIRequestError(error) {
  const container = document.querySelector('.main');
  var errorMessage;

  if(error.includes("account not found")) {
    errorMessage = "No account was found for this requester. If needed, create an account for them.";
    renderNewUserButton(container);
  } else {
    errorMessage = error;
  }

  render (
    <ThemeProvider theme={{ ...DEFAULT_THEME }}>
      <StyledDiv>
        <LG hue="red">An error occurred while trying to fetch this user's data:</LG>
        <MD hue="red">{errorMessage}</MD>
      </StyledDiv>
    </ThemeProvider>,
    container
  );
  resize_app();
}

function renderNewUserButton(parentContainer) {
  var user_id = localStorage.getItem('ticket.' + instanceGuid + '.requester_id');
  
  var settings = {
    url: '/api/v2/users/' + user_id,
    type: 'GET',
    dataType: 'json',
    contentType: 'application/json'
  };

  client.request(settings).then(
    function(res) {
      console.trace("renderNewUserButton", res);

      const parent = parentContainer;
      const container = document.createElement('div');
      container.hasAttribute('id');
      container.setAttribute('id', 'newUserButton')
      parent.appendChild(container);

      var country = localStorage.getItem('ticket.' + instanceGuid + '.country');

      if(country === "null") {
        render (
          <ThemeProvider theme={{ ...DEFAULT_THEME }}>
            <StyledDiv>
              <LG>In order to create and account, you need to first select a valid country for this ticket.</LG>
              <Button disabled>Create new user</Button>
            </StyledDiv>
          </ThemeProvider>,
          container
        );
        resize_app();
      } else {
        render (
          <ThemeProvider theme={{ ...DEFAULT_THEME }}>
            <StyledDiv>
              <Button onClick={() => showUserModal()}>Create new user</Button>
            </StyledDiv>
          </ThemeProvider>,
          container
        );
        resize_app();
      }
    },
    function(res) {
      console.error("ERROR: function {renderNewUserButton} encountered an error while tryig to get user information.", res);
    }
  );
}


function showOrderModal(orderData) {
  localStorage.setItem('ticket.' + instanceGuid + '.orderData', JSON.stringify(orderData));

  client.context().then(context => {
	  
    var parent_guid = context.instanceGuid;
    var options = {
  	  location: 'modal',
  	  url: 'assets/iframe.html#parent_guid=' + parent_guid + '&modal_type=orderDetails',
  	  size: { // optional
  	    width: '1200px',
  	    height: '550px'
  	  }
    }
    client.invoke('instances.create', options).then(function(modalContext) {
  	  // The modal is on the screen now!
  	  var modalClient = client.instance(modalContext['instances.create'][0].instanceGuid);
  	  modalClient.on('modal.close', function() {
  		// Modal has been closed
  		console.log("Modal closed correctly");        
  	  });
    });	
  });  
}

function showUserModal() {
	
  // potrei usare direttamente instanceGuid, TODO da valutare
  client.context().then(context => {
	  
    var parent_guid = context.instanceGuid;
    var options = {
  	  location: 'modal',
  	  url: 'assets/iframe.html#parent_guid=' + parent_guid + '&modal_type=userDetails',
  	  size: { // optional
  	    width: '1200px',
  	    height: '500px'
  	  }
    }
    client.invoke('instances.create', options).then(function(modalContext) {
  	  // The modal is on the screen now!
  	  var modalClient = client.instance(modalContext['instances.create'][0].instanceGuid);
  	  modalClient.on('modal.close', function() {
  		// Modal has been closed
  		console.log("Modal closed correctly");        
  	  });
    });	
  });  
}

var getUserInfo = function (gigyaId, onUserInfoLoaded) {
	  
  var callback = function(res) {
    console.log("Il risultato della chiamata authenticate: ", res);
  
    if (res.errorCode === 0) {
    
      gproxy.accounts.getAccountInfo({ "callback": onUserInfoLoaded });
  
    } else {
      console.error("ERROR: function {authenticate} ran into an error while trying to authenticate the user", res);
      renderAPIRequestError(res.errorDetails);
    }
  }

  authenticate(gigyaId, callback);

}

var authenticate = function (gigyaId, onAuthenticate) {
  var secret = localStorage.getItem('secret_key');
  gproxy(null, function() {
    gproxy.extension.install('gcustomer', {rawdata: true}).then(() => {
      gproxy.protected.authenticate({
        "client": "zendesk-client",
        "secret": secret,
        "handle": gigyaId,
        "callback" : onAuthenticate,
        "persistent" : false,
        "shared": true
      });
    }).catch((error) => {
      console.error("Cannot load extension...", error);
    });
  });

}

export function AddLibrary(urlOfTheLibrary, onLoad) {
  const script = document.createElement('script');
  if(onLoad){
    script.onload = onLoad;
  }
  script.src = urlOfTheLibrary;
  script.type = "text/javascript";
  script.async = false;
  document.body.appendChild(script);
}

function resize_app() {
  let el = document.getElementsByTagName('body')[0];
  let height = el.offsetHeight;
  let style = getComputedStyle(el);
  height += parseInt(style.marginTop) + parseInt(style.marginBottom) + 20;
  client.invoke('resize', { width: '100%', height: height });
}