const api_url="https://digitaltech-d2c-stage.herokuapp.com/js/libs/core/gproxy.js?datacenter=cdns.eu1.gigya.com&env=stage&apikey=";
const fh_api_key='4_RSjKuB-yaZHr6i2qF_HS7Q'; // stage
const pw_api_key='4_jMYUojhU1RMDxThfZyEBTg'; //stage
const secret_key='d97425fbbd871656d02fc26beb1ce6e43f1a139d384653743c272fb55d79290f';//stage
const version='2.0-rc3';
const fw_version='2.0';

var gproxyLibrary = api_url + pw_api_key;

/*
function onUILoad() {
    console.log("USERINFO LOADED");
}

function onAuthenticate() {
    console.log("AUTENTICATO");
}


var getUserInfo = function (gigyaId, onUserInfoLoaded) {  
    var callback = function(res) {
      console.log("Il risultato della chiamata authenticate: ", res);
      if (res.errorCode === 0) {
        gproxy.accounts.getAccountInfo({ "callback": onUserInfoLoaded });
      } else {
        console.error("ERROR: function {authenticate} ran into an error while trying to authenticate the user", res);
        if(res.errorDetails.includes('missing paramater [handle]')) {
          console.log("Inserire nuovo utente")
        } else {
          console.log(JSON.stringify(res.errorDetails));
        }
      }
    }
  
    authenticate(gigyaId, callback);
  }

    var authenticate = function (gigyaId, onAuthenticate) {
        var secret = secret_key;
        gproxy(null, function() {
          gproxy.extension.install('gcustomer').then(() => {
            gproxy.protected.authenticate({
              "client": "zendesk-client",
              "secret": secret,
              "handle": gigyaId,
              "callback" : onAuthenticate,
              "persistent" : false,
              "shared": true
            });
          }).catch((error) => {
            console.error("Cannot load extension...", error);
          });
        });
      
      } 
    getUserInfo('ab8a8b9bce814180a0edba8f70228454',onUILoad())
  */
   
  fetch(gproxyLibrary)
  .then((x)=> {
    
  })

 